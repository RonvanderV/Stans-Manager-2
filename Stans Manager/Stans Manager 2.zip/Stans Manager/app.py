"""
Stans Manager
Streamlit applicatie voor het toevoegen van stansvormen aan PDF-bestanden.

Auteur: Ron van der Vlerk
"""

from __future__ import annotations

from pathlib import Path
import sys

BASE_DIR = Path(__file__).resolve().parent
MODULE_DIR = BASE_DIR / "modules"

print("BASE_DIR =", BASE_DIR)
print("MODULE_DIR =", MODULE_DIR)
print("BESTAAT =", MODULE_DIR.exists())

sys.path.insert(0, str(MODULE_DIR))

import tempfile
from typing import Any, Dict, Optional

import streamlit as st

print("sys.path:")
for p in sys.path:
    print(" ", p)

import config_manager
import logger_manager
import geometry
import pdf_writer
import pdf_cleanup
import pdf_analyzer
import pdf_boxes
import spotcolor


# --------------------------------------------------
# Initialisatie
# --------------------------------------------------

logger = logger_manager.get_logger("stans_manager")

st.set_page_config(
    page_title="Stans Manager",
    page_icon="✂️",
    layout="wide",
)

# --------------------------------------------------
# Session State
# --------------------------------------------------

DEFAULT_CONFIG: Dict[str, Any] = {
    "spot_name": "CUTCONTOUR",
    "bleed_mm": 0.0,
    "stroke_width_pt": 0.25,
    "offset_x_mm": 0.0,
    "offset_y_mm": 0.0,
    "use_trimbox": True,
    "use_artbox": False,
    "use_cropbox": False,
    "use_mediabox": False,
}

for key, value in DEFAULT_CONFIG.items():
    if key not in st.session_state:
        st.session_state[key] = value

if "processed_pdf" not in st.session_state:
    st.session_state.processed_pdf = None

if "processing_done" not in st.session_state:
    st.session_state.processing_done = False

if "status_message" not in st.session_state:
    st.session_state.status_message = ""

def safe_float(value, default=0.0):
    """
    Voorkomt float(None) fouten.
    """
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def validate_box(box):
    """
    Controleert of een PDF-box geldig is.
    """
    if not isinstance(box, dict):
        raise ValueError("PDF-box is geen geldige dictionary")

    required = ["x", "y", "width", "height"]

    for key in required:
        if key not in box:
            raise ValueError(
                f"PDF-box mist sleutel '{key}'"
            )

        if box[key] is None:
            raise ValueError(
                f"PDF-box bevat None voor '{key}'"
            )

    return True

# --------------------------------------------------
# Hulpfuncties
# --------------------------------------------------

def save_uploaded_file(uploaded_file) -> Path:
    """
    Slaat een geüploade PDF tijdelijk op.
    """
    temp_dir = Path(tempfile.mkdtemp())
    pdf_path = temp_dir / uploaded_file.name

    with open(pdf_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    return pdf_path


def get_reference_box(
    pdf_path: Path,
    page_number: int,
    use_trimbox: bool,
    use_artbox: bool,
    use_cropbox: bool,
    use_mediabox: bool
) -> Dict[str, float]:
    """
    Haalt de gewenste PDF-box op.
    """

    if use_trimbox:
        return pdf_boxes.get_trimbox(pdf_path, page_number)

    if use_artbox:
        return pdf_boxes.get_artbox(pdf_path, page_number)

    if use_cropbox:
        return pdf_boxes.get_cropbox(pdf_path, page_number)

    return pdf_boxes.get_mediabox(pdf_path, page_number)


def process_pdf(
    pdf_path: Path,
    shape_type: str,
    width: float,
    height: float,
    radius: float,
    diameter: float,
    auto_size: bool,
    all_pages: bool,
) -> Path:
    """
    Hoofdverwerking.
    """

    logger.info("Start verwerking PDF")

    pdf_info = pdf_analyzer.analyze_pdf(pdf_path)

    if pdf_info is None:
        raise ValueError("PDF analyse gaf geen resultaat")

    total_pages = pdf_info.page_count

    if total_pages <= 0:
        raise ValueError(
            "Geen pagina's gevonden in PDF"
        )

    pages_to_process = (
        list(range(total_pages))
        if all_pages
        else [0]
    )

    tmp_output = pdf_path.with_name(
        f"{pdf_path.stem}_stans.pdf"
    )

    writer = pdf_writer.PDFWriter(
        output_path=tmp_output,
        spot_name=st.session_state.spot_name,
        line_width=st.session_state.stroke_width_pt,
    )

    for page_num in pages_to_process:

        box = get_reference_box(
            pdf_path,
            page_num,
            st.session_state.use_trimbox,
            st.session_state.use_artbox,
            st.session_state.use_cropbox,
            st.session_state.use_mediabox,
            validate_box(box),
        )

        x = safe_float(box.get("x"))
        y = safe_float(box.get("y"))

        box_width = safe_float(box.get("width"))
        box_height = safe_float(box.get("height"))

        if auto_size:
            width = box_width
            height = box_height
            diameter = min(box_width, box_height)

        if shape_type == "Rechthoek":

            geometry.draw_rectangle(
                writer=writer,
                page_number=page_num,
                x=x,
                y=y,
                width=width,
                height=height,
                bleed=st.session_state.bleed_mm,
            )

        elif shape_type == "Afgeronde rechthoek":

            geometry.draw_rounded_rectangle(
                writer=writer,
                page_number=page_num,
                x=x,
                y=y,
                width=width,
                height=height,
                radius=radius,
                bleed=st.session_state.bleed_mm,
            )

        elif shape_type == "Cirkel":

            geometry.draw_circle(
                writer=writer,
                page_number=page_num,
                center_x=x + (diameter / 2),
                center_y=y + (diameter / 2),
                diameter=diameter,
                bleed=st.session_state.bleed_mm,
            )

    writer.save()

    pdf_cleanup.cleanup_pdf(tmp_output)

    logger.info("PDF verwerking gereed")

    return tmp_output


# --------------------------------------------------
# Titel
# --------------------------------------------------

st.title("✂️ Stans Manager")
st.caption("Professionele PDF stansgenerator")

# --------------------------------------------------
# Sidebar
# --------------------------------------------------

with st.sidebar:

    st.header("Instellingen")

    st.session_state.spot_name = st.text_input(
        "Spotnaam",
        value=st.session_state.spot_name,
    )

    st.session_state.bleed_mm = st.number_input(
        "Bleed (mm)",
        value=safe_float(st.session_state.bleed_mm),
        step=0.1,
    )

    st.session_state.stroke_width_pt = st.number_input(
        "Lijndikte (pt)",
        value=safe_float(st.session_state.stroke_width_pt),
        step=0.05,
    )

    st.session_state.offset_x_mm = st.number_input(
        "X Offset",
        value=safe_float(st.session_state.offset_x_mm),
        step=0.1,
    )

    st.session_state.offset_y_mm = st.number_input(
        "Y Offset",
        value=safe_float(st.session_state.offset_y_mm),
        step=0.1,
    )

    st.markdown("---")

    st.subheader("PDF Box")

    st.session_state.use_trimbox = st.checkbox(
        "Gebruik TrimBox",
        value=st.session_state.use_trimbox,
    )

    st.session_state.use_artbox = st.checkbox(
        "Gebruik ArtBox",
        value=st.session_state.use_artbox,
    )

    st.session_state.use_cropbox = st.checkbox(
        "Gebruik CropBox",
        value=st.session_state.use_cropbox,
    )

    st.session_state.use_mediabox = st.checkbox(
        "Gebruik MediaBox",
        value=st.session_state.use_mediabox,
    )

    st.markdown("---")

    if st.button("💾 Config Opslaan"):

        try:
            config_manager.save_config(
                {
                    "spot_name": st.session_state.spot_name,
                    "bleed": st.session_state.bleed_mm,
                    "line_width": st.session_state.stroke_width_pt,
                    "x_offset": st.session_state.offset_x_mm,
                    "y_offset": st.session_state.offset_y_mm,
                    "use_trimbox": st.session_state.use_trimbox,
                    "use_artbox": st.session_state.use_artbox,
                    "use_cropbox": st.session_state.use_cropbox,
                    "use_mediabox": st.session_state.use_mediabox,
                }
            )

            st.success("Configuratie opgeslagen")

        except Exception as exc:
            logger.exception(exc)
            st.error(f"Opslaan mislukt: {exc}")


# --------------------------------------------------
# Upload
# --------------------------------------------------

uploaded_pdf = st.file_uploader(
    "Upload PDF",
    type=["pdf"]
)

col1, col2 = st.columns(2)

with col1:

    mode = st.selectbox(
        "Modus",
        [
            "Rechthoek",
            "Afgeronde rechthoek",
            "Cirkel",
        ]
    )

with col2:

    auto_size = st.checkbox(
        "Gebruik PDF-formaat automatisch",
        value=True
    )

st.markdown("---")

col1, col2 = st.columns(2)

with col1:

    width = st.number_input(
        "Breedte",
        min_value=0.0,
        value=50.0,
    )

    height = st.number_input(
        "Hoogte",
        min_value=0.0,
        value=30.0,
    )

with col2:

    radius = st.number_input(
        "Radius",
        min_value=0.0,
        value=3.0,
    )

    diameter = st.number_input(
        "Diameter",
        min_value=0.0,
        value=30.0,
    )

all_pages = st.checkbox(
    "Alle pagina's verwerken",
    value=True,
)

st.markdown("---")

# --------------------------------------------------
# Verwerken
# --------------------------------------------------

if st.button(
    "🚀 PDF verwerken",
    type="primary",
    use_container_width=True
):

    if uploaded_pdf is None:
        st.warning("Upload eerst een PDF.")
    else:

        try:

            status = st.status(
                "PDF verwerken...",
                expanded=True,
            )

            with status:

                status.write("PDF opslaan...")
                source_pdf = save_uploaded_file(uploaded_pdf)

                status.write("Analyse uitvoeren...")
                pdf_analyzer.analyze_pdf(source_pdf)

                status.write("Spotkleur controleren...")
                spotcolor.ensure_spot_color(
                    st.session_state.spot_name
                )

                status.write("Stans genereren...")

                output_pdf = process_pdf(
                    pdf_path=source_pdf,
                    shape_type=mode,
                    width=width,
                    height=height,
                    radius=radius,
                    diameter=diameter,
                    auto_size=auto_size,
                    all_pages=all_pages,
                )

                st.session_state.processed_pdf = output_pdf
                st.session_state.processing_done = True

                status.update(
                    label="Verwerking voltooid",
                    state="complete",
                )

            st.success("Nieuwe PDF succesvol aangemaakt.")

        except Exception as exc:

            logger.exception(exc)

            st.session_state.processing_done = False

            st.error(
                f"Fout tijdens verwerking:\n{str(exc)}"
            )

# --------------------------------------------------
# Download
# --------------------------------------------------

if (
    st.session_state.processing_done
    and st.session_state.processed_pdf is not None
):

    output_file = Path(
        st.session_state.processed_pdf
    )

    if output_file.exists():

        with open(output_file, "rb") as pdf_file:

            st.download_button(
                label="📥 Download nieuwe PDF",
                data=pdf_file.read(),
                file_name="stans_output.pdf",
                mime="application/pdf",
                use_container_width=True,
            )

    else:
        st.error(
            f"Bestand niet gevonden: {output_file}"
        )


        def run() -> bool:
            """
            Compatibiliteit met loaders
            die een run()-functie verwachten.
            """

            return True


        if __name__ == "__main__":
            run()